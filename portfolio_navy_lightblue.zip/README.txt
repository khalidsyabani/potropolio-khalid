PORTOFOLIO NAVY + LIGHT BLUE

Isi folder:
- index.html : struktur halaman
- style.css  : desain, warna, layout responsif, dan animasi
- script.js  : menu mobile, navigasi aktif, dan tahun otomatis

Cara menjalankan:
1. Ekstrak file ZIP.
2. Buka foldernya di VS Code.
3. Buka index.html dengan browser, atau gunakan ekstensi Live Server.

Yang perlu kamu ubah:
- Ganti nama "Khalid" jika ingin nama tampilan lain.
- Ganti emailkamu@example.com dengan email aktif.
- Ganti tautan GitHub/Instagram/LinkedIn dengan akunmu.
- Ganti tiga proyek contoh dengan proyek asli milikmu.
- Google Fonts memerlukan koneksi internet; jika offline, font cadangan akan digunakan.
